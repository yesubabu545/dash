#!/usr/bin/python
"""
Validate the login functionality in Space Management solution application with different users
"""
from testlogger import TestLogger
from constants import *
import requests
import xml.etree.ElementTree as ET
from xml.sax.saxutils import unescape
from sqlite import QpackDatabase

class QpackConnection:

    def __init__(self):

        self.log = TestLogger().initiate_logger(self.__class__.__name__)
        self.payload = {'User_Name': 'nagoorsaheb.inaganti', 'User_Password': 'Nagoor4QA@Soct'}
        self.payload1 = {'Username': 'nagoorsaheb.inaganti', 'UserPWD': 'Nagoor4QA@Soct'}
        self.BASE_URL = 'https://alm.orcanos.com/fio/qpackserv/qpackserv.asmx/'
        self.req_list = []
        self.test_case_list = []

    def get_projects_list(self):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """
        project_list = []
        try:
            r = requests.get(self.BASE_URL+'Get_Projects', params=self.payload)
        except ConnectionError:
            print('************************* Connection error')
            pass
        res = unescape(r.text)
        root = ET.fromstring(res)        
        for child in root[0]:            
            project_list.append(child.attrib)
        return project_list
        
    def get_versionIds(self):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """
        versionId_list = []
        url_extn = 'getProjectVersionList'
        try:
            r = requests.get(self.BASE_URL + url_extn, params=self.payload1)
        except ConnectionError:
            print('************************* Connection error')
            pass
        res = r.text        
        root = ET.fromstring(res)        
        for child in root:
            d = {}
            d['id'] = child[0].text
            d['id_ver'] = child[1].text
            d['name'] = child[2].text
            d['proj_ver'] = child[3].text
            versionId_list.append(d)
        return versionId_list

    def get_object_relation(self, obj_id):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """
        url_extn = 'Get_Object_Relations'
        self.payload['ID'] = obj_id
        try:
            r = requests.get(self.BASE_URL + url_extn, params=self.payload)
        except ConnectionError:
            print('************************* Connection error')
            pass
        res = unescape(r.text)
        root = ET.fromstring(res)
        for child in root[0]:
            if child.attrib == {}:
                print('*********************************', root[0].attrib)
            return child.attrib['target']

    def get_req_linked_to_test(self, tc_list):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """

        for item in tc_list:
            link_req = self.get_object_relation(item['id'])            
            item['source_req'] = link_req

    def get_project_tree(self, proj_id, ver_id, ItemId='', SearchTag=''):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """
        if ItemId == '':
            ItemId = proj_id
        url_extn = 'QW_Fetch_ProductTree'
        self.payload['ProjectId'] = proj_id
        self.payload['VersionId'] = ver_id
        self.payload['ItemId'] = ItemId
        self.payload['SearchTag'] = SearchTag
        root = None

        r = requests.get(self.BASE_URL + url_extn, params=self.payload)            
        res = r.text
        root = ET.fromstring(res)

        for child in root:
            if child.attrib['id'] == ItemId:                
                continue
            else:
                if child.attrib['Has_Children'] == '1':
                    self.get_project_tree(proj_id, ver_id, child.attrib['id'])
                else:
                    if child.attrib['obj_type'] == 'T_CASE':
                        self.test_case_list.append(child.attrib)
                    elif child.attrib['obj_type'] == 'SRS' or \
                         child.attrib['obj_type'] == 'REQ_HD' or \
                         child.attrib['c_code'] == 'HwRS' or \
                         child.attrib['c_code'] == 'FwRS':
                         self.req_list.append(child.attrib)

        return self.req_list, self.test_case_list

    def main(self):
        """
        Iterate through user credentials, verify and update the user ids in different sheet
        :return: None
        """
        version_id_list = []
        proj_list_with_versionIds = []

        # Get the list of Projects from Qpack
        self.log.info('\n #############################################')
        self.log.info('\n #########           Project List     ########')
        self.log.info('\n #############################################')
        project_list = self.get_projects_list()
        if project_list != []:
            # Get list of version ids for each project
            version_id_list = self.get_versionIds()
        else:
            assert False

        for i in range(len(project_list)):
            for j in range(len(version_id_list)):
                if version_id_list[j]['id'] == '1009':
                    continue
                elif (project_list[i]['id'] == version_id_list[j]['id'] and 
                    project_list[i]['name'] == version_id_list[j]['name'] and
                    project_list[i]['version'] == version_id_list[j]['proj_ver']):
                    project_list[i]['version_id'] = version_id_list[j]['id_ver']
                    proj_list_with_versionIds.append(project_list[i])
                    self.log.info('Project Name  #:   {}  version id: {}'.format(project_list[i]['name'], project_list[i]['version_id']))
        QpackDatabase().update_qpack_project_data_to_sqliteDB(proj_list_with_versionIds)

        for item in proj_list_with_versionIds:
            requirements_list = []
            test_cases_list = []
            self.req_list = []
            self.test_case_list = []
            requirements_list, test_cases_list = self.get_project_tree(item['id'], item['version_id'])
            self.log.info('\n\n ************** Count :{} {} Requirements :{}  Testcases: {}'.format(item['id'], item['version_id'],len(requirements_list),len(test_cases_list)))
            if requirements_list != []:
                QpackDatabase().update_qpack_requirement_data_to_sqliteDB(requirements_list)

            if test_cases_list != []:
                self.get_req_linked_to_test(test_cases_list)
                self.log.info('Testcases Count:{}'.format(len(test_cases_list)))
                QpackDatabase().update_qpack_testcase_data_to_sqliteDB(test_cases_list)
                


if __name__ == "__main__":
    t = QpackConnection()
    status = t.main()
