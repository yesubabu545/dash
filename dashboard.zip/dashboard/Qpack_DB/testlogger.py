#!/usr/bin/env python
"""
@brief
Logger module for unified testing overriding the APIs provided by the python logger module.
@b Description

This class inherits from the default python logger module and add the following features:
 - Allow new log level called ASSERT for assertions
 - Custom getLogger, set level, disable logging
 - Allow prefixing of the log messages using a custom adapter
 - Override the APIs provided by the

TestResults and common library modules create an instance of this logger for all the test classes

getLogger features:
 - provides a logger with handlers for stdout(stream handler) and file(filehandler).
 - Support for assert log level
 - Support for prefix for each logger instance

Unit tests: TODOClass.

@b Usage
./testlogger.py --unittest to run the unit tests
testlogger.getLogger()
"""

import os
import sys
import logging
from time import strftime
from constants import *

# Tutorial: https://docs.python.org/2/howto/logging-cookbook.html#context-info

ERROR = logging.ERROR
WARNING = logging.WARNING
INFO = logging.INFO
# ASSERTION level higher than INFO level
ASSERTION = 25
DEBUG = logging.DEBUG
NOTSET = logging.NOTSET

# Throw exceptions for FATAL or CRITICAL log messages, no need for raising logs with FATAL or CRITICAL levels


class TestLogger(object):
    """Access to logger information"""

    # The Borg Non-Pattern https://www.safaribooksonline.com/library/view/python-cookbook/0596001673/ch05s23.html
    # We only ever want one instance of a logger info class created and updated, and hence we use Borg pattern here.
    __shared_state = {}
    log_files_list = []

    def __init__(self):
        """initialise TestLogger"""
        # Borg pattern solution
        self.__dict__ = self.__shared_state
        # default log level is INFO
        if not hasattr(self, 'initial_level'):
            self.initial_level = INFO
        # log file name attribute
        if not hasattr(self, 'filename'):
            self.filename = None
        # Stdout handler
        if not hasattr(self, 'stream_handler'):
            self.stream_handler = None
        # File handler for formatting file logs
        if not hasattr(self, 'file_handler'):
            self.file_handler = None
        # Keep track of all the logging.Logger instances handed out
        if not hasattr(self, 'loggers'):
            self.loggers = []
        # The folder to store logs in, should only be set once
        if not hasattr(self, "log_folder"):
            self.log_folder = None

    def initiate_logger(self, log_prefix):
        """
        This methos to start the logging the data into a log file with the same name as script name
        :return: log data
        """
        # log_prefix = self.__class__.__name__
        test_time_stamp = strftime('%Y%m%d%H%M%S')
        log = self.get_logger(log_prefix)
        set_filename(filename=log_prefix, timestamp=test_time_stamp, log_folder=LOGS_PATH)
        return log

    def get_logger(self, log_prefix=None, disable_filelog=False, stdout_formatter=None, timestamp='', log_folder=None):
        """ Return a logger with the specified prefix, creating a file handler for the first call.
            Subsequent function alls will use the same log filename with the given title as the prefix for the logger.
            @param log_prefix - log_prefix of logger, this is also the filename for first getLogger call
            @param disable_filelog - Disable log file creation
            @param stdout_formatter - formatter for stdout logs
            @param timestamp - time stamp
            @param log_folder - the folder to store the logs in
            """
        log = logging.getLogger(log_prefix)
        # default is INFO
        log.setLevel(self.initial_level)

        # create stdout handler
        if self.stream_handler is None:

            temp_handler = logging.StreamHandler(sys.stdout)
            temp_handler.setLevel(self.initial_level)

            if stdout_formatter is None:
                formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            else:
                formatter = stdout_formatter

            temp_handler.setFormatter(formatter)
            log.addHandler(temp_handler)
            self.stream_handler = temp_handler

        # never write logs with no prefix to file
        if not disable_filelog and log_prefix is not None:
            # this handler is only set once unless explicitly changed with set_filename
            if self.file_handler is None:
                if timestamp == '':
                    timestamp = strftime('%Y%m%d%H%M%S')
                filename = "%s-%s.log" % (log_prefix, timestamp)
                if log_folder is not None and not os.path.exists(log_folder):
                    os.mkdir(log_folder)
                if log_folder is not None:
                    filename = os.path.join(log_folder, filename)
                self.log_folder = log_folder
                temp_handler = logging.FileHandler(filename)
                # default log level is INFO file handler too
                temp_handler.setLevel(self.initial_level)
                formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
                temp_handler.setFormatter(formatter)
                self.file_handler = temp_handler
                self.filename = self.file_handler.baseFilename
                TestLogger.log_files_list.append(self.filename)

            if self.file_handler is not None:
                # Add a file handle only if it is not present already.
                if len(log.handlers) < 1:
                    log.addHandler(self.file_handler)

        # Always enable assertions logs
        global ASSERTION

        if log_prefix is not None:
            # Provide a logger with custom level ASSERTION added vis _CustomAdapter class provided by python logger
            # Add prefix to all stdout and file log messages.
            log = TestLogger._CustomAdapter(log, {'prefix': log_prefix})
        # Add ASSERTION log level name for assertions added to test scripts
        logging.addLevelName(ASSERTION, 'RESULTS_METRIC')
        setattr(log,'assertion', lambda *args: log.log(ASSERTION, *args))

        log.writes_to_file = not disable_filelog and log_prefix is not None

        self.loggers.append(log)
        return log

    def renew(self):
        """Renew the logger instance"""
        # Close existing handlers saved in TestLogger shared state.
        try:
            self.formatter_file.close()
        except AttributeError:
            pass

        try:
            self.formatter_stream.close()
            log = logging.getLogger()
            log.removeHandler(self.formatter_stream)
        except AttributeError:
            pass

        # Clear the shared state
        TestLogger.__shared_state = {}

    class _CustomAdapter(logging.LoggerAdapter):
        """This adapter expects the passed in dictionary like object to have a 'prefix' key.
         This value is prefixed to the log message.
        """

        def __init__(self, logger, extra):
            super(TestLogger._CustomAdapter, self).__init__(logger, extra)
            self.writes_to_file = False

        def process(self, msg, kwargs):
            """adapter method
            @param msg - the actual log message
            @param kwargs - arguments passed on to log.method """
            return '%s - %s' % (self.extra['prefix'], msg), kwargs

        def assertion(self, msg, *args, **kwargs):
            """
            New log level for assertions created by TestResults module
            """
            return self.logger.assertion(msg, args, **kwargs)

        def setLevel(self, level):
            """Override setLevel"""
            return self.logger.setLevel(level)

        def removeHandler(self, hdlr):
            """override removeHandler"""
            return self.logger.removeHandler(hdlr)

        def addHandler(self, hdlr):
            """override addHandler"""
            return self.logger.addHandler(hdlr)

def getLogger(title=None, disable_filelog=False, stdout_formatter=None, timestamp='', log_folder=None):
    """logging module getLogger wrapper
    @param title - title of logger, used in file name, used as prefix
    @param disable_filelog - disable log file being created.
    @param stdout_formatter - formatter for the stdout logs
    @param log_folder - the folder to store the logs in
    """
    log_info = TestLogger()
    return log_info.get_logger(title, disable_filelog, stdout_formatter=stdout_formatter, timestamp=timestamp, log_folder=log_folder)


def get_filename():
    """
    Flush logger to update and return log filename
    @return: log filename
    """
    log_info = TestLogger()
    log_info.file_handler.flush()
    return log_info.filename


def log_file_time_stamp():
    """
    Returns time stamp of the current log file
    @return: [str] time stamp
    """
    log_file = get_filename()
    return log_file.split(".")[0].split("-")[-1]


def create_output_folder(foldername, timestamp=None, log_folder=None):
    output_foldername = "%s_%s" % (foldername, timestamp)
    outputfolder = os.path.join(log_folder, output_foldername)
    os.makedirs(outputfolder)
    return outputfolder


def set_filename(filename, timestamp=None, log_folder=None):
    """Set a new filename for the log - timestamp and extention are added automatically
    @param filename - name of the file without timestam and extention
    @param timestamp - optional timestamp, will otherwise be auto generated
    @param log_folder - option folder to store the log, will otherwise use the current one
    """
    log_info = TestLogger()
    log_info.file_handler.flush()
    if log_folder is None:
        log_folder = log_info.log_folder

    loggers = log_info.loggers
    # As all logging.Logger instances handed out by TestLogger share a file
    # we have to remove and reapply the handler for them all
    for logger in loggers:
        if logger.writes_to_file:
            logger.removeHandler(log_info.file_handler)

    log_info.file_handler.close()

    if log_folder is None:
        return

    if not timestamp:
        timestamp = strftime('%Y%m%d%H%M%S')
    filename = "%s-%s.log" % (filename, timestamp)
    filename = os.path.join(log_folder, filename)

    try:
        if os.path.exists(log_info.filename):
            os.rename(log_info.filename, filename)
    except OSError:
        pass

    temp_handler = logging.FileHandler(filename)
    # default log level is INFO file handler too
    temp_handler.setLevel(log_info.initial_level)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    temp_handler.setFormatter(formatter)
    log_info.file_handler = temp_handler
    log_info.filename = log_info.file_handler.baseFilename
    TestLogger.log_files_list.append(log_info.filename)

    for logger in loggers:
        if logger.writes_to_file:
            logger.addHandler(log_info.file_handler)


def set_level(level):
    """This is used to change the default log level"""
    info = TestLogger()
    info.initial_level = level


def disable(level):
    """
    Disable logs with specified level and below.
    """
    logging.disable(level)
