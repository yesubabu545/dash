execute the qpack_data file as below:
$ python3 qpack_data.py