import sqlite3
from sqlite3 import Error
from testlogger import TestLogger
from constants import *


class QpackDatabase:

    def __init__(self):
        self.database = r"fio.db"
        self.log = TestLogger().initiate_logger(self.__class__.__name__)

        # create a database connection
        self.conn = self.create_connection(self.database)

        #create table for projects
        self.create_table(self.conn, SQL_CREATE_PROJECTS_TABLE)
        self.create_table(self.conn, SQL_CREATE_REQ_TABLE)
        self.create_table(self.conn, SQL_CREATE_TC_TABLE)

    def create_connection(self, db_file):
        """ create a database connection to the SQLite database
            specified by db_file
        :param db_file: database file
        :return: Connection object or None
        """
        conn = None
        try:
            conn = sqlite3.connect(db_file)
        except Error as e:
            print(e)

        return conn

    def create_table(self, conn, create_table_sql):
        """ create a table from the create_table_sql statement
        :param conn: Connection object
        :param create_table_sql: a CREATE TABLE statement
        :return:
        """
        try:
            c = conn.cursor()
            c.execute(create_table_sql)
        except Error as e:
            print(e)

    def add_project(self, conn, project):
        """
        Create a new project into the projects table
        :param conn:
        :param project:
        :return: project id
        """
        sql = ''' INSERT INTO projects(name,
                                        proj_id,
                                        proj_version,
                                        type,
                                        version_id
                                        )
                                        VALUES(?,?,?,?,?) '''
        cur = conn.cursor()
        cur.execute(sql, project)
        conn.commit()
        self.log.info('Project added to Database: {}'.format(project))
        return cur.lastrowid


    def add_requirement(self, conn, task):
        """
        Create a new requirement
        :param conn:
        :param task:
        :return:
        """
        sql = ''' INSERT INTO requirements(proj_ver_id,name,req_id,c_code,parent_id,type,path,has_children)
                VALUES(?,?,?,?,?,?,?,?) '''
        cur = conn.cursor()
        cur.execute(sql, task)
        conn.commit()
        self.log.info('Requirement added to Database: {} of Project vId{}'.format(task[1], task[0]))
        return cur.lastrowid

    def add_testcase(self, conn, task):
        """
        Create a new testcase
        :param conn:
        :param task:
        :return:
        """
        sql = ''' INSERT INTO testcases(proj_ver_id,name,source_req,tc_id,c_code,parent_id,type,path,has_children)
                VALUES(?,?,?,?,?,?,?,?,?) '''
        cur = conn.cursor()
        cur.execute(sql, task)
        conn.commit()
        self.log.info('Testcase added to Database: {} of Project vId{}'.format(task[1], task[0]))
        return cur.lastrowid

    def update_qpack_project_data_to_sqliteDB(self, data):
        """
        Update the qpack response data to the Sqlite database
        The order of the params data should be: name ,
                                        proj_id ,
                                        proj_version ,
                                        type ,
                                        version_id ,
        :param data: Data from Rest Api response
        """
        for i in data:
            proj_data = tuple([i['name'], i['id'], i['version'], i['type'], i['version_id']])            
            proj_id = self.add_project(self.conn, proj_data)

    def update_qpack_requirement_data_to_sqliteDB(self, data):
        """
        Update the qpack response data to the Sqlite database
        The order of the params data should be: proj_ver_id text
                                    name text NOT NULL,
                                    req_id text,                                    
                                    c_code text,
                                    parent_id text,
                                    type text,
                                    path text,
                                    has_children text,
        :param data: Data from Rest Api response
        """

        for i in data:            
            proj_data = tuple([i['Version_id'],i['obj_name'], i['id'], i['c_code'], i['parent_id'], i['obj_type'],
                                    i['path'],i['Has_Children']])
            proj_id = self.add_requirement(self.conn, proj_data)

    def update_qpack_testcase_data_to_sqliteDB(self, data):
        """
        Update the qpack response data to the Sqlite database
        The order of the params data should be: proj_ver_id text
                                    name text NOT NULL,
                                    source_req text,
                                    tc_id text,                                    
                                    c_code text,
                                    parent_id text,
                                    type text,
                                    path text,
                                    has_children text,
        :param data: Data from Rest Api response
        """

        for i in data:            
            proj_data = tuple([i['Version_id'],i['obj_name'],i['source_req'],i['id'], i['c_code'], i['parent_id'], i['obj_type'],
                                    i['path'],i['Has_Children']])
            proj_id = self.add_testcase(self.conn, proj_data)

