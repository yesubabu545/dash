import os
SQL_CREATE_PROJECTS_TABLE = """ CREATE TABLE IF NOT EXISTS projects (
                                        id integer PRIMARY KEY,
                                        name text NOT NULL,
                                        proj_id text,
                                        proj_version text,
                                        type text,
                                        version_id text,
                                        createdAt text,
                                        updatedAt text
                                    ); """

SQL_CREATE_REQ_TABLE = """CREATE TABLE IF NOT EXISTS requirements (
                                    id integer PRIMARY KEY,
                                    proj_ver_id text,
                                    name text NOT NULL,
                                    req_id text,                                    
                                    c_code text,
                                    parent_id text,
                                    type text,
                                    path text,
                                    has_children text,
                                    createdAt text,
                                    updatedAt text
                                );"""

SQL_CREATE_TC_TABLE = """CREATE TABLE IF NOT EXISTS testcases (
                                    id integer PRIMARY KEY,
                                    proj_ver_id text,
                                    source_req text,
                                    name text NOT NULL,
                                    tc_id text,                                    
                                    c_code text,
                                    parent_id text,
                                    type text,
                                    path text,
                                    has_children text,
                                    createdAt text,
                                    updatedAt text
                                );"""

LOGS_PATH = os.path.join(os.path.dirname(__file__), 'logs')