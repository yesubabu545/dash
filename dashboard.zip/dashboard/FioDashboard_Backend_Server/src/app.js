/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global require process*/
/*eslint no-undef: "error"*/

const express = require('express')
const bodyParser  = require('body-parser')
const cors = require('cors')
const morgan = require('morgan')
const {sequelize} = require('./models')
const config = require('./config/config')
const multer = require('multer')
const path = require('path')

const app = express()
app.use(morgan('combined'))
app.use(bodyParser.json({limit: '150mb', extended: true}))
app.use(bodyParser.urlencoded({limit: '150mb', extended: true}))
app.use(cors())

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        var uploadpath = path.join(__dirname, '..', 'uploads')
        cb(null, uploadpath)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now())
    }
})

var upload = multer({ storage: storage })


require('./routes/projects-routes')(app)
require('./routes/requirements-routes')(app)
require('./routes/testcase-routes')(app)

sequelize.sync({force: false})
    .then(() => {
        app.listen(config.PORT)
        console.log(`Server started on port ${config.PORT}`)
    })
