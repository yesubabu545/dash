/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module*/
/*eslint no-undef: "error"*/

module.exports = (sequelize, DataTypes) => 
    sequelize.define('Projects', {
        name: DataTypes.STRING,
        proj_id: DataTypes.STRING,
        proj_version: DataTypes.STRING,
        type: DataTypes.STRING,
        version_id: DataTypes.STRING
})
