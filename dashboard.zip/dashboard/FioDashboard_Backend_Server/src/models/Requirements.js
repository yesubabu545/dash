/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module*/
/*eslint no-undef: "error"*/

module.exports = (sequelize, DataTypes) => 
    sequelize.define('Requirements', {
        proj_ver_id: DataTypes.STRING,
        name: DataTypes.STRING,
        req_id:DataTypes.STRING,
        c_code: DataTypes.STRING,
        parent_id: DataTypes.STRING,
        type: DataTypes.STRING,
        path: DataTypes.STRING,
        has_children: DataTypes.STRING
})
