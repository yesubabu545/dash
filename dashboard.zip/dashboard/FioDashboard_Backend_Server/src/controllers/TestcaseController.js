/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const {Testcases} = require('../models')

module.exports = {    
    async getalltestcases (req, res) {
        try {
            const tc = await Testcases.findAll({
                where: {}
            })            
            res.send(tc)
        } catch (err) {            
            res.status(500).send({
                error: 'An error occurred while getting testcases!'
            })
        }
    },
    async gettestcases (req, res) {
        try {
            const tc = await Testcases.findAll({
                where: {
                    'proj_ver_id': req.params.projId
                }
            })
            res.send(tc)
        } catch (err) {
            res.status(500).send({
                error: 'An error occurred while getting testcases!'
            })
        }
    },
    async gettestcaseslength (req, res) {
        try {
            const tc = await Testcases.findAndCountAll({
                where: {
                    'proj_ver_id': req.params.projId
                },
                attributes: [
                    'id'
                ]
            })
            res.send(tc)
        } catch (err) {
            res.status(500).send({
                error: 'An error occurred while getting testcases length!'
            })
        }
    },
    async gettestcase (req, res) {
        try {
            const tc = await Testcases.findAll ({
                where: {
                    'proj_ver_id': req.params.projId,
                    'tc_id': req.params.testcaseId
                }
            })
            res.send(tc)
        } catch (err) {
            res.status(500).send({
                error: 'an error occurred while getting the testcase!'
            })
        }
    },

    async getlinkedtestcasecount(req, res){
        try{
            const tc = await Testcases.findAndCountAll({
                where: {
                    'proj_ver_id': req.params.projId,
                    'source_req': req.params.reqId
                },
                attributes: [
                    'id'
                ]
            })
            res.send(tc)
        } catch (err){
            res.status(500).send({
                error: 'an error occurred while getting linked requirements'
            })
        }
    },

    async getlinkedtestcases(req, res){
        try{
            const tc = await Testcases.findAll({
                where: {
                    'proj_ver_id': req.params.projId,
                    'source_req': req.params.reqId
                },
            })
            res.send(tc)
        } catch (err){
            res.status(500).send({
                error: 'an error occurred while getting linked requirements'
            })
        }
    }
}