/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const {Requirements} = require('../models')

module.exports = {    
    async getallrequirements (req, res) {
        try {
            const requirements = await Requirements.findAll({
            })
            res.send(requirements)
        } catch (err) {            
            res.status(500).send({
                error: 'An error occurred while getting projects!'
            })
        }
    },
    async getrequirements (req, res) {
        try {
            const requirements = await Requirements.findAll({
                where: {
                    'proj_ver_id': req.params.projId
                }
            })
            res.send(requirements)
        } catch (err) {            
            res.status(500).send({
                error: 'An error occurred while getting projects!'
            })
        }
    },
    async getrequirementslength (req, res) {
        try {
            const requirements = await Requirements.findAndCountAll({
                where: {
                    'proj_ver_id': req.params.projId
                },
                attributes: [
                    'id'
                ]
            })
            res.send(requirements)
        } catch (err) {
            res.status(500).send({
                error: 'An error occurred while getting projects length!'
            })
        }
    },
    async getrequirement (req, res) {
        try {
            const requirement = await Requirements.findAll ({
                where: {
                    'req_id': req.params.requirementId,
                    'proj_ver_id': req.params.projId
                }
            })
            res.send(requirement)
        } catch (err) {
            res.status(500).send({
                error: 'an error occurred while getting the project!'
            })
        }
    },
    async getrequirementbyid (req, res) {
        try {
            const requirement = await Requirements.findByPk(req.params.Id)            
            res.send(requirement)
        } catch (err) {
            res.status(500).send({
                error: 'an error occurred while getting the project!'
            })
        }
    },
}