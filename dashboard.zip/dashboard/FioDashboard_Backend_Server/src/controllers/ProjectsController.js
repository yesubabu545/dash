/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const {Projects} = require('../models')

module.exports = {    
    async getprojects (req, res) {
        try {
            const projects = await Projects.findAll({
                where: {}
            })
            res.send(projects)
        } catch (err) {
            res.status(500).send({
                error: 'An error occurred while getting projects!'
            })
        }
    },
    async getprojectslength (req, res) {
        try {
            const projects = await Projects.findAndCountAll({
                where: {},
                attributes: [
                    'id'
                ]
            })
            res.send(projects)
        } catch (err) {
            res.status(500).send({
                error: 'An error occurred while getting projects length!'
            })
        }
    },
    async getproject (req, res) {
        try {
            const project = await Projects.findByPk (req.params.projectId)
            res.send(project)
        } catch (err) {
            res.status(500).send({
                error: 'an error occurred while getting the project!'
            })
        }
    },
}