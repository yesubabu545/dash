/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module process*/
/*eslint no-undef: "error"*/

/***
 * This config is used when the data is updated to sqlite runtime
 */
module.exports = {
    PORT: process.env.PORT || 8083,
    db: {
        database: process.env.DB_NAME || 'dashboard',
        user: process.env.DB_USER || 'dbuser',
        password: process.env.DB_PASS || 'dbpassword',
        options: {
            dialect: process.env.DB_DIALECT || 'sqlite',
            host: process.env.HOST || 'localhost',
            storage: './release-dashboard.sqlite'
        }
    }
}
