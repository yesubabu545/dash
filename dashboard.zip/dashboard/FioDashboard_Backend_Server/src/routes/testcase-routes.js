/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const TestcaseController = require('../controllers/TestcaseController')

module.exports = (app) => {    
    app.get('/alltestcases',
        TestcaseController.getalltestcases),    
    app.get('/projects/:projId/testcases',
        TestcaseController.gettestcases),
    app.get('/projects/:projId/testcaseslength',
        TestcaseController.gettestcaseslength),
    app.get('/projects/:projId/testcase/:testcaseId',
        TestcaseController.gettestcase)
    app.get('/projects/:projId/linkedtestcasecount/:reqId',
        TestcaseController.getlinkedtestcasecount)
    app.get('/projects/:projId/linkedtestcases/:reqId',
        TestcaseController.getlinkedtestcases)
}
