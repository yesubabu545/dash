/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const RequirementController = require('../controllers/RequirementsController')

module.exports = (app) => {    
    app.get('/allrequirements',
        RequirementController.getallrequirements)
    app.get('/projects/:projId/requirements',
        RequirementController.getrequirements),
    app.get('/projects/:projId/requirementslength',
        RequirementController.getrequirementslength),
    app.get('/projects/:projId/requirement/:requirementId',
        RequirementController.getrequirement),
    app.get('/projects/:projId/requirementbyid/:Id',
        RequirementController.getrequirementbyid)
}
