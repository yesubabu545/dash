/*************************************************************************
* Copyright(C) 2019-2020 Advanced Micro Devices, Inc. All rights reserved.
*************************************************************************/

/*global module require*/
/*eslint no-undef: "error"*/

const ProjectController = require('../controllers/ProjectsController')

module.exports = (app) => {    
    app.get('/projects',
        ProjectController.getprojects),
    app.get('/projectslength',
        ProjectController.getprojectslength),
    app.get('/projects/:projectId',
        ProjectController.getproject)
}
