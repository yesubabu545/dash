<template>
  <v-navigation-drawer
    v-model="inputValue"
    absolute
    floating
    width="500"
    temporary
    style="position: fixed; top: 0; left: 0"
  >
    <v-list>
      <v-list-tile avatar @click.stop="navigateTo({ name: 'Dashboard' })">
        <v-list-tile-avatar>
          <v-icon>fas fa-home</v-icon>
        </v-list-tile-avatar>
        <v-list-tile-title>Home</v-list-tile-title>
      </v-list-tile>
      <v-list>
        <div v-if="projects">
          <div v-for="rel in projects" :key="rel.id">
            <v-list-tile
              @click="
                navigateTo({
                  name: 'Release',
                  params: {
                    releaseId: rel.id,
                  },
                })
              "
            >
              <v-list-tile-title>
                <div v-if="rel.name.length < 35">
                  {{ rel.name }} ({{ rel.proj_version }})
                </div>
                <div v-else>
                  <v-tooltip right>
                    <template v-slot:activator="{ on }">
                      <div v-on="on">
                        {{ rel.name.substring(0, 34) + "..." }}
                      </div>
                    </template>
                    <span> {{ rel.name }} ({{ rel.proj_version }}) </span>
                  </v-tooltip>
                </div>
              </v-list-tile-title>
              <v-list-tile-action>
                <v-icon light>far fa-file</v-icon>
              </v-list-tile-action>
            </v-list-tile>
          </div>
        </div>
      </v-list>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
import ReleaseService from "@/services/ReleaseService";
// Utilities
import { mapMutations, mapState } from "vuex";

export default {
  data: () => ({
    drawer: false,
    responsive: false,
    projects: [],
  }),
  computed: {
    ...mapState("app", ["image", "color"]),
    inputValue: {
      get() {
        return this.$store.state.app.drawer;
      },
      set(val) {
        this.setDrawer(val);
      },
    },
    items() {
      return this.$t("Layout.View.items");
    },
    sidebarOverlayGradiant() {
      return `${this.$store.state.app.sidebarBackgroundColor}, ${this.$store.state.app.sidebarBackgroundColor}`;
    },
  },
  async mounted() {
    this.onResponsiveInverted();
    window.addEventListener("resize", this.onResponsiveInverted);
    // this.releasesfolders = (await ReleaseService.getfolders()).data
    // Get All Releases Information for comparison
    var relcount = (await ReleaseService.getprojectslength()).data;
    for (let index = 0; index < relcount.count; index++) {
      var sampleRelease = {
        id: null,
        createdAt: null,
        name: null,
        proj_id: null,
        proj_version: null,
        type: null,
        version_id: null,
        updatedAt: null,
      };
      var relInfo = (await ReleaseService.getproject(relcount.rows[index].id))
        .data;
      var relid = relcount.rows[index].id;
      // sampleRelease.id = relid
      sampleRelease = relInfo;
      // console.log("******* release count", sampleRelease);
      this.projects.push(sampleRelease);
    }
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.onResponsiveInverted);
  },
  methods: {
    ...mapMutations("app", ["setDrawer", "toggleDrawer"]),
    onResponsiveInverted() {
      if (window.innerWidth < 991) {
        this.responsive = true;
      } else {
        this.responsive = false;
      }
    },
    navigateTo(route) {
      this.$router.push(route);
    },
  },
};
</script>

<style lang="scss">
#app-drawer {
  .v-list__tile {
    border-radius: 4px;

    &--buy {
      margin-top: auto;
      margin-bottom: 17px;
    }
  }

  .v-image__image--contain {
    top: 9px;
    height: 60%;
  }

  .search-input {
    margin-bottom: 30px !important;
    padding-left: 15px;
    padding-right: 15px;
  }

  div.v-responsive.v-image > div.v-responsive__content {
    overflow-y: auto;
  }
}
</style>
