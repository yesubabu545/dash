<template>
  <v-toolbar fixed class="grey lighten-3" id="core-toolbar" prominent>
    <v-tooltip right>
      <template v-slot:activator="{ on }">
        <v-toolbar-side-icon v-on="on">
          <v-icon large class="ml-3" color="grey" @click.stop="onClickBtn">
            fas fa-bars
          </v-icon>
        </v-toolbar-side-icon>
      </template>
      <span>Releases Menu</span>
    </v-tooltip>
    <v-spacer></v-spacer>
    <v-tooltip right>
      <template v-slot:activator="{ on }">
        <v-toolbar-side-icon v-on="on">
          <v-icon
            class="ml-3"
            large
            color="grey"
            @click="navigateTo({ name: 'Dashboard' })"
          >
            fas fa-home
          </v-icon>
        </v-toolbar-side-icon>
      </template>
      <span>Home</span>
    </v-tooltip>
    <v-spacer></v-spacer>
    <v-flex xs5>
      <div class="v-toolbar-title">
        <v-toolbar-title class="tertiary--text font-weight-dark ml-5">
          FIO Project Dashboard
        </v-toolbar-title>
      </div>
    </v-flex>
    <v-spacer></v-spacer>
    <v-flex xs4>
      <v-autocomplete
        class="autocomplete-bar-position"
        color="black"
        v-model="relId"
        :items="releases"
        :loading="isLoading"
        :search-input.sync="search"
        clearable
        hide-no-data
        hide-selected
        :item-text="(item) => item.name + ' - ' + item.proj_version"
        item-value="id"
        placeholder="Start typing to Search Releases"
      >
      </v-autocomplete>
    </v-flex>
    <v-spacer></v-spacer>
    <v-flex xs2>
      <v-toolbar-items>
        <v-btn
          class="search-button-position"
          ripple
          color="indigo"
          :loading="isLoading"
          v-if="relId"
          @click="
            navigateTo({
              name: 'Release',
              params: {
                releaseId: relId,
              },
            })
          "
        >
          Search
        </v-btn>
      </v-toolbar-items>
    </v-flex>
  </v-toolbar>
</template>

<script>
import { mapMutations } from "vuex";
import ReleaseService from "@/services/ReleaseService";

export default {
  data: () => ({
    drawer: null,
    title: null,
    responsive: false,
    responsiveInput: false,
    search: null,
    relId: null,
    // releasesfolders: null,
    releases: [],
    descriptionLimit: 60,
    isLoading: false,
  }),
  async mounted() {
    this.onResponsiveInverted();
    window.addEventListener("resize", this.onResponsiveInverted);
    // this.releasesfolders = (await ReleaseService.getfolders()).data
    this.releases = (await ReleaseService.getprojects()).data;
  },
  beforeDestroy() {
    window.removeEventListener("resize", this.onResponsiveInverted);
  },
  methods: {
    ...mapMutations("app", ["setDrawer", "toggleDrawer"]),
    onClickBtn() {
      this.setDrawer(!this.$store.state.app.drawer);
    },
    navigateTo(route) {
      this.$router.push(route);
    },
    onResponsiveInverted() {
      if (window.innerWidth < 991) {
        this.responsive = true;
        this.responsiveInput = false;
      } else {
        this.responsive = false;
        this.responsiveInput = true;
      }
    },
    navigateTo(route) {
      this.$router.push(route);
    },
  },
  watch: {
    search(val) {
      // Items have already been loaded
      if (this.releases.length > 0) return;

      // Items have already been requested
      if (this.isLoading) return;

      this.isLoading = true;

      // Lazily load input items
      fetch("http://localhost:8080/projects") // atgasia01:8091 - 10.67.247.61:8091
        .then((res) => res.json())
        .then((res) => {
          this.count = res.length;
          this.releases = res;
        })
        .catch((err) => {
          console.log(err);
        })
        .finally(() => (this.isLoading = false));
    },
  },
};
</script>

<style>
#core-toolbar a {
  text-decoration: none;
}
.v-toolbar {
  font-family: Arial, Helvetica, sans-serif;
}
.autocomplete-bar-position {
  left: 20%;
}
.search-button-position {
  left: 50%;
}
</style>
