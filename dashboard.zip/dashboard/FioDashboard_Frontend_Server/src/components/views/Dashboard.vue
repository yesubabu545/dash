<template>
  <v-container>
    <div>
      <material-card
        color="blue-grey darken-2"
        title="Welcome to the Fio Dashboard"
      >
        <v-card class="outline grey lighten-2 expansion-panel-margin">
          <v-list-tile>
            <v-list-tile-title class="mx-2 font-weight-black tile-margin-top">
              Project Vs Requirements
            </v-list-tile-title>
          </v-list-tile>
          <div class="grey lighten-2 mx-2">
            <ve-histogram
              height="500px"
              :extend="reqPrioritiesChartExtend"
              :legend="chartLegend"
              :data="reqPriorityChartData"
              :dataZoom="chartDataZoom"
              :settings="reqPrioritiesChartSettings"
              :toolbox="chartToolbox"
            >
            </ve-histogram>
          </div>
        </v-card>
      </material-card>
    </div>
    <material-card
            color="blue-grey darken-2"
            title="Project Dashboard">
            <v-layout wrap>
                <v-flex xs12>
                        <v-expansion-panel class="outline expansion-panel-margin" v-model="projectSummaryPanel" expand>
                            <v-expansion-panel-content class="grey lighten-2">
                                <template v-slot:header>
                                    <div class="font-weight-black">Requirements Summary</div>
                                </template>
                                <material-card class="grey lighten-2">
                                    <v-layout row wrap>
                                        <v-flex xs8>
                                            <v-text-field
                                                v-model="searchTC"
                                                prepend-icon="fas fa-search"
                                                label="Search Project"
                                                class="my-2"
                                                clearable
                                                hide-details>
                                            </v-text-field>
                                        </v-flex>
                                        <v-spacer></v-spacer>
                                        <v-flex xs3>
                                            <v-list-tile-sub-title class="my-4">Total Projects: {{ project_len }}</v-list-tile-sub-title>
                                        </v-flex>
                                    </v-layout>
                                    <v-data-table
                                        :headers="projectHeaders"
                                        :items="projects"
                                        :search="searchTC"                                        
                                        class="elevation-1 outline3">
                                        <template v-slot:items="testfields">                                            
                                            <td class="text-xs-center" >
                                                {{ testfields.item.proj_id }}
                                            </td>                                            
                                            <td class="text-xs-center">                                                
                                                {{ testfields.item.name }}
                                            </td>                                            
                                            <td class="text-xs-center">
                                                {{ testfields.item.proj_version }}
                                            </td>
                                            <td class="text-xs-center">
                                                 {{ testfields.item.version_id }} 
                                            </td>
                                            <td class="font-weight-black black--text text-xs-center" >
                                                {{ testfields.item.req_count }} 
                                            </td>
                                        </template>
                                        <template v-slot:no-results>
                                            <v-alert :value="true" color="red accent-1" icon="fas fa-exclamation-triangle">
                                            Your search for "{{ searchTC }}" found no results.
                                            </v-alert>
                                        </template>
                                    </v-data-table>
                                </material-card>
                            </v-expansion-panel-content>
                        </v-expansion-panel>
                </v-flex>
            </v-layout>
    </material-card>
    <v-dialog
        v-model="loadDashboardPageDialog"
        hide-overlay
        persistent
        width="400">
        <v-card
            color="primary"
            dark>
            <v-card-text>
                Please wait for the operation to complete!
                <v-progress-linear
                    indeterminate
                    color="white"
                    class="mb-0">
                </v-progress-linear>
            </v-card-text>
        </v-card>
    </v-dialog> 
  </v-container>
</template>

<script>
import ReleaseService from "@/services/ReleaseService";
import RequirementService from "@/services/RequirementService";
import TestcaseService from "@/services/TestcaseService";
import VeLine from "v-charts/lib/line.common";
import VeHistogram from "v-charts/lib/histogram.common";
import "echarts/lib/component/toolbox";
import "echarts/lib/component/title";
import "echarts/lib/component/legend";
import "echarts/lib/component/dataZoom";
export default {
  components: { VeLine, VeHistogram },
  data() {
    return {
      projects: [],
      project_len: null,
      project: {
        proj_name: null,
        "No of Req": null,
      },
      loadDashboardPageDialog: true,
      searchTC:"",
      reqPriorityChartData: {
        columns: ["proj_name", "No of Req"],
        rows: [],
      },
      projectSummaryPanel: [ true ],
      projectHeaders: [
                {
                    text: 'Project ID ',
                    value: 'proj_id',
                    class: 'green lighten-2 font-weight-black black--text text-xs-center'
                },
                {
                    text: 'Title ',
                    value: 'name',
                    class: 'green lighten-2 font-weight-black black--text text-xs-center'
                },
                {
                    text: 'Version',
                    value: 'proj_version',
                    class: 'green lighten-2 font-weight-black black--text text-xs-center'
                },
                {
                    text: 'Project Version ID ',
                    value: 'version_id',
                    class: 'green lighten-2 font-weight-black black--text text-xs-center'
                },
                {
                    text: 'No of Requirements ',
                    value: 'req_count',
                    class: 'green lighten-2 font-weight-black black--text text-xs-center'
                }
            ],
    };
  },
  created: function () {
    // Release Bug Priorities Indicator Chart Settings
    this.reqPrioritiesChartSettings = {
      yAxisType: ["KMB"],
      xAxisName: ["Project Name"],
      yAxisName: ["No. of Requirements"],      
      label: {
        normal: {
          show: true,
          color: "#000",
          fontWeight:"bold"

        },
      },
    };

    // Release Bug Priorities Chart Axis Label Font Settings
    this.reqPrioritiesChartExtend = {
      "grid.left": "3%",
      "xAxis.0.axisLabel.rotate": 60,
      "yAxis.0.nameLocation": "center",      
      "yAxis.0.nameGap": 35,
      fontWeight: "bold",
      color: ["#B71C1C", "#EF5350", "#FFEE58", "#4CAF50", "#5E35B1"],
      "series.0.z": 3,
    };

    this.chartLegend = {
      top: 10,
      // selected: {
      //     'Undefined': false
      // }
    };

    // Indicator Chart Tool Box Settings
    this.chartToolbox = {
      showTitle: false,
      feature: {
        saveAsImage: {},
      },
    };
    // Indicator Chart Title Settings
    this.chartTitle = {
      text: "",
      subtext: "",
      backgroundColor: "white",
      textStyle: {
        fontWeight: "bold",
      },
      subtextStyle: {
        rich: {
          pass: {
            color: "#4CAF50",
            fontWeight: "bold",
            fontSize: "16",
          },
          condpass: {
            color: "#FFC107",
            fontWeight: "bold",
            fontSize: "16",
          },
          fail: {
            color: "#F44336",
            fontWeight: "bold",
            fontSize: "16",
          },
        },
      },
      textAlign: "center",
      left: "15%",
      borderWidth: 2,
      borderRadius: 5,
    };
    // Indicator Chart Data Zoom Settings
    this.chartDataZoom = [
      {
        type: "inside",
        start: 40,
        end: 100,
      },
      {
        type: "slider",
      },
    ];
  },
  methods: {
    // Route function to navigate to another page
    navigateTo(route) {
      this.$router.push(route);
    },
    onScroll(e) {
      if (typeof window === "undefined") return;
      const top = window.pageYOffset || e.target.scrollTop || 0;
      this.fab = top > 20;
    },
    // Navigate to Top of the Screen
    toTop() {
      this.$vuetify.goTo(0);
    },
    // Modify Release Name to short Release Name
    modToShortReleaseName(relName, ver) {
      var rname = relName;
      if (rname.includes("Deki Reader")) {
        rname = rname.replace("Deki Reader", "DR");
        //  relName;
      }
      if (rname.includes("Software")) {
        rname = rname.replace("Software", "SW");
        // return relName;
      }
      if (rname.includes("System")) {
        rname = rname.replace("System", "Sys");
        // return relName;
      }
      return rname + "(" + ver + ")";
    },
  },
  async mounted() {
    this.loadDashboardPageDialog = true;
    // Get All Releases Information for comparison
    var relcount = (await ReleaseService.getprojectslength()).data;
    this.project_len = relcount.count;
    for (let index = 0; index < relcount.count; index++) {
      var sampleRelease = {
        id: null,
        createdAt: null,
        name: null,
        proj_id: null,
        proj_version: null,
        type: null,
        version_id: null,
        updatedAt: null,
        req_count: null,
      };

      var relInfo = (await ReleaseService.getproject(relcount.rows[index].id))
        .data;
      // console.log('********:', relcount.rows[index].id)
      sampleRelease = relInfo;
      var req_info = (
        await RequirementService.getrequirementslength(
          sampleRelease["version_id"]
        )
      ).data;
      sampleRelease["req_count"] = req_info.count;
      this.projects.push(sampleRelease);

      this.reqPriorityChartData.rows.push({
        proj_name: this.modToShortReleaseName(relInfo["name"], relInfo["proj_version"]),
        "No of Req": req_info.count,
      });
    }

    // console.log("***********Projects :", this.projects);

    // this.projects.forEach((prj) => {
    //   this.reqPriorityChartData.rows.push({
    //     proj_name: this.modToShortReleaseName(prj["name"], prj["proj_version"]),
    //     "No of Req": prj["req"],
    //   });
    // });
    // console.log('*************', this.reqPriorityChartData)
    // Sorting the Regression, New, Open, Fixed & Closed Issues

    this.loadDashboardPageDialog = false;
  },  
};
</script>

<style>
body {
  text-align: justify;
  font-size: 20px;
}
.outline {
  outline-style: dotted;
  outline-width: thin;
  -moz-outline-radius: 5px;
  margin: 5px;
}
.outline2 {
  outline-style: dashed;
  -moz-outline-radius: 5px;
}
.outline3 {
  outline-style: solid;
  outline-color: black;
}
.expansion-panel-margin {
  margin-top: 8px;
}
td {
  font-family: Arial, Helvetica, sans-serif;
}
.v-list {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.v-text-field {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
}
.v-container {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
}
.v-list__tile__sub-title {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
  text-align: center;
}
.text-align-right {
  text-align: right;
}
.text-align-left {
  text-align: left;
}
.text-align-center {
  text-align: center;
}
.position-edit-release {
  margin-top: 150px;
}
.position-add-release {
  margin-top: 90px;
}
.custom-padding-tile {
  padding-top: 5px;
  padding-bottom: 5px;
  padding-left: 10px;
  padding-right: 10px;
}
.custom-title-text {
  font-size: 20px;
}
</style>
