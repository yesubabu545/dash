<template>
  <v-container>
    <material-card>
      <h2 class="mx-auto font-weight-black text-xs-center">
        Project Information
      </h2>
      <v-layout row wrap>
        <v-flex xs12>
          <v-expansion-panel
            class="outline expansion-panel-margin"
            v-model="relInfoPanel"
            expand
          >
            <v-expansion-panel-content class="grey lighten-2">
              <template v-slot:header>
                <div class="font-weight-black">Summary</div>
              </template>
              <v-layout row wrap>
                <v-flex xs7>
                  <v-layout row wrap class="white outline">
                    <v-flex xs4>
                      <v-list-tile>
                        <v-list-tile-title class="font-weight-black"
                          >Name:</v-list-tile-title
                        >
                      </v-list-tile>
                    </v-flex>
                    <v-flex xs8>
                      <v-list-tile>
                        <v-list-tile-title class="body-1 text-align-right">
                          {{ project.name }}
                        </v-list-tile-title>
                      </v-list-tile>
                    </v-flex>
                  </v-layout>
                </v-flex>
                <v-flex xs5>
                  <v-layout row wrap class="white outline">
                    <v-flex xs4>
                      <v-list-tile>
                        <v-list-tile-title class="font-weight-black"
                          >Version:</v-list-tile-title
                        >
                      </v-list-tile>
                    </v-flex>
                    <v-flex xs8>
                      <v-list-tile>
                        <v-list-tile-title class="body-1 text-align-right">
                          {{ project.proj_version }}
                        </v-list-tile-title>
                      </v-list-tile>
                    </v-flex>
                  </v-layout>
                </v-flex>
                <v-flex xs7>
                  <v-list-tile class="outline white">
                    <v-list-tile-title class="font-weight-black"
                      >Project Id:</v-list-tile-title
                    >
                    <v-list-tile-sub-title class="text-align-right">{{
                      project.proj_id
                    }}</v-list-tile-sub-title>
                  </v-list-tile>
                </v-flex>
                <v-flex xs5>
                  <v-list-tile class="outline white">
                    <v-list-tile-title class="font-weight-black"
                      >Version Id:</v-list-tile-title
                    >
                    <v-list-tile-sub-title class="text-align-right">{{
                      project.version_id
                    }}</v-list-tile-sub-title>
                  </v-list-tile>
                </v-flex>
                <v-flex xs7>
                  <v-list-tile class="outline white">
                    <v-list-tile-title class="font-weight-black"
                      >No Of Requirements:
                    </v-list-tile-title>
                    <v-list-tile-sub-title class="text-align-right">{{
                      no_of_req.count
                    }}</v-list-tile-sub-title>
                  </v-list-tile>
                </v-flex>
                <v-flex xs5>
                  <v-list-tile class="outline white">
                    <v-list-tile-title class="font-weight-black"
                      >No Of Testcases:
                    </v-list-tile-title>
                    <v-list-tile-sub-title class="text-align-right">
                      {{ no_of_testcases.count }}
                    </v-list-tile-sub-title>
                  </v-list-tile>
                </v-flex>
              </v-layout>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-flex>
      </v-layout>
    </material-card>
    <div>
      <material-card
        color="blue-grey darken-2"
        title="Welcome to the Fio Dashboard"
      >
        <v-card class="outline grey lighten-2 expansion-panel-margin">
          <v-list-tile>
            <v-list-tile-title class="mx-2 font-weight-black tile-margin-top">
              Requirements Vs Testcases
            </v-list-tile-title>
          </v-list-tile>
          <div class="grey lighten-2 mx-2">
            <ve-histogram
              height="500px"
              :extend="reqPrioritiesChartExtend"
              :legend="chartLegend"
              :data="reqPriorityChartData"
              :dataZoom="chartDataZoom"
              :settings="reqPrioritiesChartSettings"
              :toolbox="chartToolbox"
            >
            </ve-histogram>
          </div>
        </v-card>
      </material-card>
    </div>
    <div>
      <material-card>
        <v-flex xs12>
          <div v-if="requirements.length">
            <v-expansion-panel
              class="outline expansion-panel-margin"
              v-model="projectSummaryPanel"
              expand
            >
              <v-expansion-panel-content class="grey lighten-2">
                <template v-slot:header>
                  <div class="font-weight-black">Requirements & Testcases</div>
                </template>
                <material-card class="grey lighten-2">
                  <v-tabs
                    grow
                    active-class="blue lighten-2"
                    color="transparent"
                  >
                    <v-tab class="font-weight-black"> Requirements </v-tab>
                    <v-tab-item>
                      <material-card class="grey lighten-2">
                        <v-layout row wrap>
                          <v-flex xs8>
                            <v-text-field
                              v-model="searchTC"
                              prepend-icon="fas fa-search"
                              label="Search Project"
                              class="my-2"
                              clearable
                              hide-details
                            >
                            </v-text-field>
                          </v-flex>
                          <v-spacer></v-spacer>
                          <v-flex xs3>
                            <v-list-tile-sub-title class="my-4"
                              >Total Requirements:
                              {{ no_of_req.count }}</v-list-tile-sub-title
                            >
                          </v-flex>
                        </v-layout>
                        <v-data-table
                          :headers="reqHeaders"
                          :items="requirements"
                          :search="searchTC"
                          item-key="id"
                          :expand="compExpand"
                          class="elevation-1 outline3"
                        >
                          <template v-slot:items="testfields">
                            <tr @click="expandCtsModule(testfields)">
                              <td class="text-xs-center">
                                {{ testfields.item.req_id }}
                              </td>
                              <td class="text-xs-center">
                                {{ testfields.item.name }}
                              </td>
                              <td class="text-xs-center">
                                {{ testfields.item.type }}
                              </td>
                              <td class="text-xs-center">
                                {{ testfields.item.proj_ver_id }}
                              </td>
                              <td
                                class="font-weight-black black--text text-xs-center"
                              >
                                {{ testfields.item.req_count }}
                              </td>
                            </tr>
                          </template>

                          <template v-slot:expand="testfields">
                            <div
                              v-if="testfields"
                              class="elevation-1 outline3 mx-3 my-2"
                            >
                              <v-data-table
                                :headers="LinktcHeaders"
                                :items="linked_tests"
                                :expand="ctsModuleFailureStackTraceExpand"
                                hide-actions
                                class="elevation-1 outline3"
                              >
                                <template v-slot:items="cases">
                                  <tr @click="cases.expanded = !cases.expanded">
                                    <td class="text-xs-center" width="10">
                                      {{ cases.item.tc_id }}
                                    </td>
                                    <td class="text-xs-center" width="10">
                                      {{ cases.item.name }}
                                    </td>
                                    <td class="text-xs-center" width="25">
                                      {{ cases.item.type }}
                                    </td>
                                  </tr>
                                </template>
                              </v-data-table>
                            </div>
                          </template>

                          <template v-slot:no-results>
                            <v-alert
                              :value="true"
                              color="red accent-1"
                              icon="fas fa-exclamation-triangle"
                            >
                              Your search for "{{ searchTC }}" found no results.
                            </v-alert>
                          </template>
                        </v-data-table>
                      </material-card>
                    </v-tab-item>

                    <v-tab class="font-weight-black"> TestCases </v-tab>
                    <v-tab-item>
                      <material-card class="grey lighten-2">
                        <v-layout row wrap>
                          <v-flex xs8>
                            <v-text-field
                              v-model="searchTC"
                              prepend-icon="fas fa-search"
                              label="Search Testcase"
                              class="my-2"
                              clearable
                              hide-details
                            >
                            </v-text-field>
                          </v-flex>
                          <v-spacer></v-spacer>
                          <v-flex xs3>
                            <v-list-tile-sub-title class="my-4"
                              >Total Testcases:
                              {{ no_of_testcases.count }}</v-list-tile-sub-title
                            >
                          </v-flex>
                        </v-layout>
                        <v-data-table
                          :headers="tcHeaders"
                          :items="testcases"
                          :search="searchTC"
                          class="elevation-1 outline3"
                        >
                          <template v-slot:items="testfields">
                            <td class="text-xs-center">
                              {{ testfields.item.tc_id }}
                            </td>
                            <td class="text-xs-center">
                              {{ testfields.item.name }}
                            </td>
                            <td class="text-xs-center">
                              {{ testfields.item.type }}
                            </td>
                            <td
                              class="font-weight-black black--text text-xs-center"
                            >
                              {{ testfields.item.source_req }}
                            </td>
                          </template>
                          <template v-slot:no-results>
                            <v-alert
                              :value="true"
                              color="red accent-1"
                              icon="fas fa-exclamation-triangle"
                            >
                              Your search for "{{ searchTC }}" found no results.
                            </v-alert>
                          </template>
                        </v-data-table>
                      </material-card>
                    </v-tab-item>
                  </v-tabs>
                </material-card>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </div>
        </v-flex>
      </material-card>

      <v-tooltip left>
        <template v-slot:activator="{ on }">
          <v-btn
            v-scroll="onScroll"
            v-show="fab"
            v-on="on"
            color="indigo darken-2"
            dark
            @click="toTop"
            fab
            fixed
            bottom
            right
          >
            <v-icon>fas fa-angle-up</v-icon>
          </v-btn>
        </template>
        <span>Navigate to Top</span>
      </v-tooltip>
    </div>
    <v-dialog
      v-model="loadReleasePageDialog"
      hide-overlay
      persistent
      width="400"
    >
      <v-card color="primary" dark>
        <v-card-text>
          Please wait for the operation to complete!
          <v-progress-linear indeterminate color="white" class="mb-0">
          </v-progress-linear>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import ReleaseService from "@/services/ReleaseService";
import RequirementService from "@/services/RequirementService";
import TestcaseService from "@/services/TestcaseService";
import VeLine from "v-charts/lib/line.common";
import VeHistogram from "v-charts/lib/histogram.common";
import "echarts/lib/component/toolbox";
import "echarts/lib/component/title";
import "echarts/lib/component/legend";
import "echarts/lib/component/dataZoom";
export default {
  components: { VeLine, VeHistogram },
  data() {
    return {
      loadReleasePageDialog: true,
      id: 0,
      searchTC: "",
      projects: [],
      projectSummaryPanel: [true],
      ctsModuleFailureStackTraceExpand: false,
      requirements: [],
      linked_tests: [],
      compExpand: false,
      testcases: [],
      relInfoPanel: [true],
      no_of_projs: {
        count: null,
        id: [],
      },
      fab: false,
      no_of_req: {
        count: null,
        id: [],
      },
      no_of_testcases: {
        count: null,
        id: [],
      },
      project: {
        id: 0,
        createdAt: null,
        name: null,
        proj_id: null,
        proj_version: null,
        type: null,
        version_id: null,
        updatedAt: null,
      },
      requirement: {
        id: 0,
        proj_ver_id: null,
        name: null,
        req_id: null,
        c_code: null,
        parent_id: null,
        type: null,
        path: null,
        has_children: null,
        createdAt: null,
        updatedAt: null,
      },
      testcase: {
        id: 0,
        createdAt: null,
        name: null,
        tc_id: null,
        proj_id: null,
        proj_version: null,
        type: null,
        version_id: null,
        updatedAt: null,
      },
      reqPriorityChartData: {
        columns: ["req_name", "No of TC"],
        rows: [],
      },
      reqHeaders: [
        {
          text: "Requirement ID ",
          value: "req_id",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Title ",
          value: "name",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Type",
          value: "type",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Project Version ID ",
          value: "version_id",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "No of Linked Tests ",
          value: "req_count",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
      ],
      tcHeaders: [
        {
          text: "Testcase ID ",
          value: "tc_id",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Title ",
          value: "name",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Type",
          value: "type",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Linked requirement ID",
          value: "source_req",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
      ],
      LinktcHeaders: [
        {
          text: "Testcase ID ",
          value: "tc_id",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Title ",
          value: "name",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
        {
          text: "Type",
          value: "type",
          class: "green lighten-2 font-weight-black black--text text-xs-center",
        },
      ],
    };
  },
  created: function () {
    // Release Bug Priorities Indicator Chart Settings
    this.reqPrioritiesChartSettings = {
      yAxisType: ["KMB"],
      xAxisName: ["Requirement ID"],
      yAxisName: ["No. of Testcases"],
      label: {
        normal: {
          show: true,
          color: "#000",
          fontWeight: "bold",
        },
      },
    };

    // Release Bug Priorities Chart Axis Label Font Settings
    this.reqPrioritiesChartExtend = {
      "grid.left": "3%",
      "xAxis.0.axisLabel.rotate": 60,
      "yAxis.0.nameLocation": "center",
      "yAxis.0.nameGap": 35,
      color: ["#FA8072", "#B71C1C", "#EF5350", "#FFEE58", "#4CAF50"],
      "series.0.z": 3,
    };

    this.chartLegend = {
      top: 10,
      // selected: {
      //     'Undefined': false
      // }
    };

    // Indicator Chart Tool Box Settings
    this.chartToolbox = {
      showTitle: false,
      feature: {
        saveAsImage: {},
      },
    };
    // Indicator Chart Title Settings
    this.chartTitle = {
      text: "",
      subtext: "",
      backgroundColor: "white",
      textStyle: {
        fontWeight: "bold",
      },
      subtextStyle: {
        rich: {
          pass: {
            color: "#4CAF50",
            fontWeight: "bold",
            fontSize: "16",
          },
          condpass: {
            color: "#FFC107",
            fontWeight: "bold",
            fontSize: "16",
          },
          fail: {
            color: "#F44336",
            fontWeight: "bold",
            fontSize: "16",
          },
        },
      },
      textAlign: "center",
      left: "15%",
      borderWidth: 2,
      borderRadius: 5,
    };
    // Indicator Chart Data Zoom Settings
    this.chartDataZoom = [
      {
        type: "inside",
        start: 40,
        end: 100,
      },
      {
        type: "slider",
      },
    ];
  },
  methods: {
    // Route function to navigate to another page
    navigateTo(route) {
      this.$router.push(route);
    },
    onScroll(e) {
      if (typeof window === "undefined") return;
      const top = window.pageYOffset || e.target.scrollTop || 0;
      this.fab = top > 20;
    },
    // Navigate to Top of the Screen
    toTop() {
      this.$vuetify.goTo(0);
    },
    // Modify Release Name to short Release Name
    modToShortReleaseName(relName, ver) {
      var rname = relName;
      if (rname.includes("Deki Reader")) {
        rname = rname.replace("Deki Reader", "DR");
        //  relName;
      }
      if (rname.includes("Software")) {
        rname = rname.replace("Software", "SW");
        // return relName;
      }
      if (rname.includes("System")) {
        rname = rname.replace("System", "Sys");
        // return relName;
      }
      return rname + "(" + ver + ")";
    },
    async expandCtsModule(expId) {
      try {
        this.linked_tests = (
          await TestcaseService.getlinkedtestcases(
            expId.item.proj_ver_id,
            expId.item.req_id
          )
        ).data;
        // console.log('LInked:', this.linked_tests)
      } catch (err) {
        console.log(err);
      }
      if (expId.item) {
        expId.expanded = !expId.expanded;
      }
    },
  },
  async mounted() {
    this.loadReleasePageDialog = true;
    this.id = this.$route.params.releaseId;
    Object.assign(
      this.project,
      (await ReleaseService.getproject(this.id)).data
    );

    var relcount = (
      await RequirementService.getrequirementslength(this.project.version_id)
    ).data;

    Object.assign(
      this.no_of_req,
      (await RequirementService.getrequirementslength(this.project.version_id))
        .data
    );
    // this.requirements = (await RequirementService.getrequirements(this.project.version_id)).data;

    this.testcases = (
      await TestcaseService.gettestcases(this.project.version_id)
    ).data;
    Object.assign(
      this.no_of_testcases,
      (await TestcaseService.gettestcaseslength(this.project.version_id)).data
    );

    for (let index = 0; index < relcount.count; index++) {
      var sampleRelease = {
        id: null,
        proj_ver_id: null,
        name: null,
        req_id: null,
        c_code: null,
        parent_id: null,
        type: null,
        path: null,
        has_children: null,
        createdAt: null,
        updatedAt: null,
        req_count: null,
      };

      var relInfo = (
        await RequirementService.getrequirementbyid(
          this.project.version_id,
          relcount.rows[index].id
        )
      ).data;
      sampleRelease = relInfo;
      var req_info = (
        await TestcaseService.getlinkedtestcasecount(
          relInfo["proj_ver_id"],
          relInfo["req_id"]
        )
      ).data;
      sampleRelease["req_count"] = req_info.count;
      this.requirements.push(sampleRelease);

      this.reqPriorityChartData.rows.push({
        req_name: relInfo["req_id"],
        "No of TC": req_info.count,
      });
    }
    this.loadReleasePageDialog = false;
  },
};
</script>


<style>
body {
  text-align: justify;
  font-size: 20px;
}
.outline {
  outline-style: dotted;
  outline-width: thin;
  -moz-outline-radius: 5px;
  margin: 5px;
}
.outline2 {
  outline-style: dashed;
  -moz-outline-radius: 5px;
}
.outline3 {
  outline-style: solid;
  outline-color: black;
}
.expansion-panel-margin {
  margin-top: 8px;
}
td {
  font-family: Arial, Helvetica, sans-serif;
}
.v-list {
  font-family: Arial, Helvetica, sans-serif;
  font-size: small;
}
.v-text-field {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
}
.v-container {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
}
.v-list__tile__sub-title {
  font-family: Arial, Helvetica, sans-serif;
  color: black;
  text-align: center;
}
.text-align-right {
  text-align: right;
}
.text-align-left {
  text-align: left;
}
.text-align-center {
  text-align: center;
}
.position-edit-release {
  margin-top: 150px;
}
.position-add-release {
  margin-top: 90px;
}
.custom-padding-tile {
  padding-top: 5px;
  padding-bottom: 5px;
  padding-left: 10px;
  padding-right: 10px;
}
.custom-title-text {
  font-size: 20px;
}
</style>
