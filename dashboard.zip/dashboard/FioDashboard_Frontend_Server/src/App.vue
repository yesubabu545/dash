<template>
  <v-app>
    <!-- <core-filter /> -->

    <core-toolbar/>

    <core-drawer />

    <core-view :key="$route.fullPath"/>
    <!-- <v-fade-transition mode="out-in">
      <router-view :key="$route.fullPath"/>
    </v-fade-transition> -->
  </v-app>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="scss">
@import '@/styles/index.scss';

</style>
