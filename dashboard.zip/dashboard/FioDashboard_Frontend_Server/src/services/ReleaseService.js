import Api from '@/services/Api'

export default {
    getfolders () {
        return Api().get('folders')
    },
    postfolder (folder) {
        return Api().post('folders', folder)
    },
    getprojects () {
        return Api().get('projects')
    },
    getprojectslength () {
        return Api().get('projectslength')
    },
    getproject (projectId) {
        return Api().get(`projects/${projectId}`)
    },
    
}
