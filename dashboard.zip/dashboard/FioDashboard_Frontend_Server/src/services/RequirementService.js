import Api from '@/services/Api'

export default {
    getallrequirements () {
        return Api().get(`allrequirements`)
    },
    getrequirements (projId) {
        return Api().get(`projects/${projId}/requirements`)
    },
    getrequirementslength (projId) {
        return Api().get(`projects/${projId}/requirementslength`)
    },
    getrequirement (projId,reqId) {
        return Api().get(`projects/${projId}/requirement/${reqId}`)
    },
    getrequirementbyid(projId,Id) {
        return Api().get(`projects/${projId}/requirementbyid/${Id}`)
    }
}
