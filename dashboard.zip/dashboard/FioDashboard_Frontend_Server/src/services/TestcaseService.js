import Api from '@/services/Api'

export default {
    getalltestcases () {
        return Api().get('alltestcases')
    },
    gettestcases (projId) {
        return Api().get(`projects/${projId}/testcases`)
    },
    gettestcaseslength (projId) {
        return Api().get(`projects/${projId}/testcaseslength`)
    },
    gettestcase (projId,tcId) {
        return Api().get(`projects/${projId}/testcases/${tcId}`)
    },
    getlinkedtestcasecount(projId,reqId){
        return Api().get(`projects/${projId}/linkedtestcasecount/${reqId}`)
    },
    getlinkedtestcases(projId,reqId){
        return Api().get(`projects/${projId}/linkedtestcases/${reqId}`)
    }
}
