import axios from 'axios'

export default () => {
    return axios.create({
        // baseURL: 'http://172.31.32.148:8083/'
        // baseURL: 'http://atgasia01:8091/'        // atgasia01:8091 - 10.67.247.61:8091
        baseURL: ' http://localhost:8083/'
    })
}