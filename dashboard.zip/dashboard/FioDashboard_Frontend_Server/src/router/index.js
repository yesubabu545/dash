import Vue from 'vue'
import Router from 'vue-router'
import DashboardView from '@/components/views/Dashboard'
import ReleaseView from '@/components/views/Release'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Dashboard',
      component: DashboardView
    },
    {
      path: '/:releaseId',
      name: 'Release',
      component: ReleaseView
    },
  ]
})
