// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Vuetify from 'vuetify'
import VueResource from 'vue-resource'
import VueEditor from 'vue2-editor'
import 'vuetify/dist/vuetify.min.css'
import '@fortawesome/fontawesome-free/css/all.css' // Ensure you are using css-loader
import store from '@/store'

// Sync router with store
import { sync } from 'vuex-router-sync'

// Components
import './components'

// Sync store with router
sync(store, router)

Vue.config.productionTip = false
Vue.use(Vuetify, {
  iconfont: 'fa'
})
Vue.use(VueResource)
Vue.use(VueEditor)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
